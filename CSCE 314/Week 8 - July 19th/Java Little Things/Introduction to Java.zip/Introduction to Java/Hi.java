
public class Hi {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hello, World!");
		System.out.println("Time to relearn Java!");
		for (int i = 0; i < 5; i++) {
			System.out.println(i);
		}
	}

}
