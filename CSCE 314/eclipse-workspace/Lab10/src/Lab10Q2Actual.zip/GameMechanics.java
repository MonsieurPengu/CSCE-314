import java.util.ArrayList;
import java.util.Arrays;

public class GameMechanics {
	static boolean BattleTester(ArrayList<? extends Character> list) {
		for (int i = 0; i < list.size(); i++) {
			if (list.get(0).getClass() != list.get(i).getClass()) {
				return false;
			}
		}
		return true;
	}
	
	static String basicWinChances(Hero tempHero, Villain tempVillain) {
		int heroHearts = tempHero.getHearts();
		int villainHearts = tempVillain.getHearts();
		int winnerHearts = 0;
		
		if (heroHearts > villainHearts) {
			winnerHearts = heroHearts/villainHearts;
			return "Hero " + tempHero.getName() + " " + heroHearts + " to " + villainHearts;
		}
		else if (villainHearts > heroHearts) {
			winnerHearts = villainHearts/heroHearts;
			return "Villain " + tempVillain.getName() + " " + villainHearts + " to " + heroHearts;
		}
		else {
			return "Even match.";
		}
	}
	
	public static void main(String[] args) {
		ArrayList<Character> villainList = new ArrayList<Character>();
		Villain testVillain1 = new Villain("Creeper", new Location(0, 1, 0), false, "axe", 6);
		Villain testVillain2 = new Villain("Zombie", new Location(0, 1, 0), false, "shovel", 6);
		villainList.add(testVillain1);
		villainList.add(testVillain2);
		BattleTester(villainList);
		
		Block testBlock = new Block("copper", new Location(0, 0, 0), 5);
		villainList.add(villainList);
		BattleTester(villainList);
		
		/*Villain testVillain = new Villain("Creeper", new Location(0, 1, 0), false, "axe", 6);
		System.out.println(testVillain);

		
		Hero testHero = new Hero("Bowen", new Location(0, 0, 40), Arrays.asList("iron sword", "beef", "flare"), 5, 0) ;
		System.out.println(testHero);
		
		System.out.println(basicWinChances(testHero, testVillain));
		
		Villain testVillain1 = new Villain("Creeper", new Location(0, 2, 0), false, "shovel", 3);
		System.out.println(testVillain1);

		
		Hero testHero1 = new Hero("Bowen", new Location(0, 0, 42), Arrays.asList("diamond sword", "pork", "ice"), 7, 0) ;
		System.out.println(testHero1);
		
		System.out.println(basicWinChances(testHero1, testVillain1));*/
	}
}
