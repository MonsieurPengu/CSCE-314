import java.util.ArrayList;

public class GameMechanics {
	static boolean BattleTester(ArrayList<? extends Character> list) {
		for (int i = 0; i < list.size(); i++) {
			if (list.get(0).getClass() != list.get(i).getClass()) {
				return false;
			}
		}
		return true;
	}
	
	public static void main(String[] args) {
		ArrayList<Character> villainList = new ArrayList<Character>();
		Villain testVillain1 = new Villain("Creeper", new Location(0, 1, 0), false, "axe", 6);
		Villain testVillain2 = new Villain("Zombie", new Location(0, 1, 0), false, "shovel", 6);
		villainList.add(testVillain1);
		villainList.add(testVillain2);
		BattleTester(villainList);
		
		Block testBlock = new Block("copper", new Location(0, 0, 0), 5);
		villainList.add(villainList);
		BattleTester(villainList);
	}
}
